
from statistics import mean
x_AUC = []
y_AUC = []

singapore = [49, 57.59, 50.5, 52.8, 55.96, 59.57, 54.74]
singapore_NN = [51, 59, 51, 58, 57, 49]
singapore.append(round(mean(singapore_NN), 2))
x_AUC.append("Singapore")
y_AUC.append(mean(singapore))

malaysia = [49, 56.48, 49.8, 51.6, 52.33, 59.98, 49]
malaysia_NN = [49, 50, 49, 53, 50, 47]
malaysia.append(round(mean(malaysia_NN), 2))
x_AUC.append("Malaysia")
y_AUC.append(mean(malaysia))

thailand = [45, 50.37, 52.7, 51.4, 56.41, 51.20, 51]
thailand_NN = [51, 55, 51, 52, 52, 48]
thailand.append(round(mean(thailand_NN), 2))
x_AUC.append("Thailand")
y_AUC.append(mean(thailand))

jakarta = [53, 53.45, 59.6, 51.3, 53.15, 51.04, 50.38]
jakarta_NN = [52, 53, 52, 49, 49, 48]
jakarta.append(round(mean(jakarta_NN), 2))
x_AUC.append("Jakarta")
y_AUC.append(mean(jakarta))

# =========================================================================================

x_HR = ["AdaBoost", "DA", "KF", "KNN", "Logit", "RFC", "SVC", "ANN"]
y_HR = []

sgp = [59.21, 59.69, 56.6, 56.2, 60.17, 52.69, 59.59]
sgp_NN = [54.67, 59.71, 59.53, 55.68, 59.67, 59.70]
sgp.append(round(mean(sgp_NN), 2))

malay = [56.13, 57.01, 54.9, 56.6, 55.74, 54.74, 59.63]
malay_NN = [59.60, 56.80, 55.99, 59.71, 54.06, 57.8] 
malay.append(round(mean(malay_NN), 2))

thl = [60.60, 62.14, 52.8, 59.7, 58.06, 53.84, 59.45]
thl_NN = [57.54, 62.98, 59.17, 60.80, 59.46, 59.99]
thl.append(round(mean(thl_NN), 2))

jkt = [60.83, 53.40, 56.6, 59.8, 59.85, 53.31, 59.56]
jkt_NN = [59.24, 52.89, 59.31, 59.10, 53.32, 55.15]
jkt.append(round(mean(jkt_NN), 2))

# =================Plotting===============================================================

# from matplotlib import pyplot as plt

# plt.scatter(x_HR, singapore, c = "r", label = "Singapore")
# for i, txt in enumerate(singapore):
#     plt.annotate(txt, (x_HR[i], singapore[i]))

# plt.scatter(x_HR, malaysia, c = "g", label = "Malaysia")
# for i, txt in enumerate(malaysia):
#     plt.annotate(txt, (x_HR[i], malaysia[i]))

# plt.scatter(x_HR, thailand, c = "b", label = "Thailand")
# for i, txt in enumerate(thailand):
#     plt.annotate(txt, (x_HR[i], thailand[i]))

# plt.scatter(x_HR, jakarta, c = "y", label = "Jakarta")
# for i, txt in enumerate(jakarta):
#     plt.annotate(txt, (x_HR[i], jakarta[i]))

# # plt.plot(x_HR, singapore, c = "r", label = "Singapore")
# # plt.plot(x_HR, malaysia, c = "g", label = "Malaysia")
# # plt.plot(x_HR, thailand, c = "b", label = "Thailand")
# # plt.plot(x_HR, jakarta, c = "y", label = "Jakarta")

# plt.plot(x_HR, singapore, c = "r")
# plt.plot(x_HR, malaysia, c = "g")
# plt.plot(x_HR, thailand, c = "b")
# plt.plot(x_HR, jakarta, c = "y")

# plt.xlabel("Algorithm")
# plt.ylabel("Mean AUC")
# plt.title("Mean AUC per Algorithm")
# plt.legend()
# plt.show()

# ====================Printing Hit Ratios===============================================

import pandas as pd

lst = []
lst.append(singapore)
lst.append(malaysia)
lst.append(thailand)
lst.append(jakarta)

df = pd.DataFrame(lst, index = x_AUC, columns = x_HR)
print(df)

# ======================Printing Hidden Nodes Hit Ratio=======================================================

lst2 = []
lst2.append(singapore_NN)
lst2.append(malaysia_NN)
lst2.append(thailand_NN)
lst2.append(jakarta_NN)


df2 = pd.DataFrame(lst2, index = x_AUC, columns = [2, 4, 6, 8, 10, 12])
print("\n\nNumber of Hidden Nodes to Hit Ratio\n")
print(df2)
print("\n\n")